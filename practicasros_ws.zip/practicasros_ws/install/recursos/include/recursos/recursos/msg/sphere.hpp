// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef RECURSOS__MSG__SPHERE_HPP_
#define RECURSOS__MSG__SPHERE_HPP_

#include "recursos/msg/detail/sphere__struct.hpp"
#include "recursos/msg/detail/sphere__builder.hpp"
#include "recursos/msg/detail/sphere__traits.hpp"
#include "recursos/msg/detail/sphere__type_support.hpp"

#endif  // RECURSOS__MSG__SPHERE_HPP_
