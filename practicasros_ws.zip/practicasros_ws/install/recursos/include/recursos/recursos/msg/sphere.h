// generated from rosidl_generator_c/resource/idl.h.em
// with input from recursos:msg/Sphere.idl
// generated code does not contain a copyright notice

#ifndef RECURSOS__MSG__SPHERE_H_
#define RECURSOS__MSG__SPHERE_H_

#include "recursos/msg/detail/sphere__struct.h"
#include "recursos/msg/detail/sphere__functions.h"
#include "recursos/msg/detail/sphere__type_support.h"

#endif  // RECURSOS__MSG__SPHERE_H_
