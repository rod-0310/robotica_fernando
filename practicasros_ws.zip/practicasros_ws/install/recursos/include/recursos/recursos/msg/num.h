// generated from rosidl_generator_c/resource/idl.h.em
// with input from recursos:msg/Num.idl
// generated code does not contain a copyright notice

#ifndef RECURSOS__MSG__NUM_H_
#define RECURSOS__MSG__NUM_H_

#include "recursos/msg/detail/num__struct.h"
#include "recursos/msg/detail/num__functions.h"
#include "recursos/msg/detail/num__type_support.h"

#endif  // RECURSOS__MSG__NUM_H_
