// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef RECURSOS__MSG__NUM_HPP_
#define RECURSOS__MSG__NUM_HPP_

#include "recursos/msg/detail/num__struct.hpp"
#include "recursos/msg/detail/num__builder.hpp"
#include "recursos/msg/detail/num__traits.hpp"
#include "recursos/msg/detail/num__type_support.hpp"

#endif  // RECURSOS__MSG__NUM_HPP_
