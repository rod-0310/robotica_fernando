// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from recursos:msg/Num.idl
// generated code does not contain a copyright notice

#ifndef RECURSOS__MSG__DETAIL__NUM__TYPE_SUPPORT_HPP_
#define RECURSOS__MSG__DETAIL__NUM__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "recursos/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_recursos
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  recursos,
  msg,
  Num
)();
#ifdef __cplusplus
}
#endif

#endif  // RECURSOS__MSG__DETAIL__NUM__TYPE_SUPPORT_HPP_
