// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef RECURSOS__SRV__COORDENADAS_HPP_
#define RECURSOS__SRV__COORDENADAS_HPP_

#include "recursos/srv/detail/coordenadas__struct.hpp"
#include "recursos/srv/detail/coordenadas__builder.hpp"
#include "recursos/srv/detail/coordenadas__traits.hpp"
#include "recursos/srv/detail/coordenadas__type_support.hpp"

#endif  // RECURSOS__SRV__COORDENADAS_HPP_
