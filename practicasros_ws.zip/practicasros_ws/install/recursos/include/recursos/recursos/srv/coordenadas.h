// generated from rosidl_generator_c/resource/idl.h.em
// with input from recursos:srv/Coordenadas.idl
// generated code does not contain a copyright notice

#ifndef RECURSOS__SRV__COORDENADAS_H_
#define RECURSOS__SRV__COORDENADAS_H_

#include "recursos/srv/detail/coordenadas__struct.h"
#include "recursos/srv/detail/coordenadas__functions.h"
#include "recursos/srv/detail/coordenadas__type_support.h"

#endif  // RECURSOS__SRV__COORDENADAS_H_
