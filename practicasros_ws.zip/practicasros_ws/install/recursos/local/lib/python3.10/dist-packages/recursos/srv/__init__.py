from recursos.srv._coordenadas import Coordenadas  # noqa: F401
